const CUR="₹";
const PLANS=[
 {n:"MINI",r:"1 GB",c:"1 vCPU",d:"10 GB",p:10},
 {n:"STARTER",r:"2 GB",c:"150% CPU",d:"15 GB",p:20},
 {n:"BASIC",r:"4 GB",c:"200% CPU",d:"25 GB",p:40},
 {n:"PLUS",r:"6 GB",c:"250% CPU",d:"40 GB",p:70},
 {n:"PRO",r:"8 GB",c:"300% CPU",d:"50 GB",p:130},
 {n:"ULTRA",r:"12 GB",c:"350% CPU",d:"70 GB",p:160},
 {n:"ADVANCED",r:"16 GB",c:"400% CPU",d:"90 GB",p:200},
 {n:"TITAN",r:"24 GB",c:"450% CPU",d:"120 GB",p:250},
 {n:"EXTREME",r:"32 GB",c:"500% CPU",d:"160 GB",p:450},
 {n:"GOD",r:"48 GB",c:"600% CPU",d:"200 GB",p:590},
 {n:"GOD PLUS",r:"64 GB",c:"800% CPU",d:"250 GB",p:699}
];
const FEATS=["AMD Ryzen 7","NVMe SSD","DDoS Protection","AetherPanel","High Performance"];
const $=s=>document.querySelector(s);
const money=p=>p?CUR+p+"/mo":"Free";

// Plans page
if($("#planGrid")){
 $("#planGrid").innerHTML=PLANS.map(x=>`<div class="card"><h3>${x.n}</h3>
 <div class="price">${CUR}${x.p}<small> /month</small></div>
 <ul><li>${x.r} RAM</li><li>${x.c}</li><li>${x.d} NVMe</li></ul>
 <a class="btn" href="payment.html?plan=${encodeURIComponent(x.n)}">Choose ${x.n}</a></div>`).join("");
 $("#featList").innerHTML=FEATS.map(f=>`<span class="pill on-p">${f}</span>`).join(" ");
}

// Payment page
if($("#pSel")){
 $("#pSel").innerHTML=PLANS.map(x=>`<option value="${x.n}">${x.n} – ${x.r} – ${CUR}${x.p}/mo</option>`).join("");
 const q=new URLSearchParams(location.search).get("plan");
 if(q&&PLANS.some(p=>p.n===q))$("#pSel").value=q;
 const tot=()=>{$("#pTot").textContent=money(PLANS.find(p=>p.n===$("#pSel").value).p)};
 $("#pSel").onchange=tot;tot();
 document.querySelectorAll("[data-pay]").forEach(b=>b.onclick=()=>{
  const em=$("#pEmail").value.trim();
  $("#pMsg").textContent=em?`Order created: ${$("#pSel").value} plan via ${b.dataset.pay}. Connect your payment gateway here.`:"Enter your email before paying."
 });
}

// Dashboard page (demo)
if($("#bStart")){
 let up=false,t;const con=$("#con");
 const log=m=>{con.innerHTML+="<br>"+m;con.scrollTop=con.scrollHeight};
 const render=()=>{
  $("#sStat").textContent=up?"Online":"Offline";$("#sStat").className="pill "+(up?"on-p":"off-p");
  const r=up?+(1+Math.random()*2).toFixed(1):0,c=up?Math.round(10+Math.random()*40):0,p=up?Math.floor(Math.random()*12):0;
  $("#ramT").textContent=r+" / 4 GB";$("#ramB").style.width=r/4*100+"%";
  $("#cpuT").textContent=c+"%";$("#cpuB").style.width=c+"%";$("#plr").textContent=p+" / 20";
 };
 const start=()=>{if(up)return;log("Starting server...");setTimeout(()=>{up=true;log("Done! Server is online.");render();t=setInterval(render,3000)},1200)};
 const stop=()=>{if(!up)return;up=false;clearInterval(t);log("Server stopped.");render()};
 $("#bStart").onclick=start;$("#bStop").onclick=stop;
 $("#bRestart").onclick=()=>{stop();setTimeout(start,800)};
}

// Downloads page
if($("#dlGrid")){
 const FILES=[
  {n:"server.properties",d:"Base config: 20 slots, normal difficulty.",c:"motd=Welcome to my server\nmax-players=20\ndifficulty=normal\ngamemode=survival\nview-distance=10\nonline-mode=true\nserver-port=25565\n"},
  {n:"start.sh",d:"Start script for Linux or macOS with 4 GB RAM.",c:"#!/bin/bash\njava -Xms2G -Xmx4G -jar server.jar nogui\n"},
  {n:"start.bat",d:"Start script for Windows with 4 GB RAM.",c:"@echo off\njava -Xms2G -Xmx4G -jar server.jar nogui\npause\n"},
  {n:"eula.txt",d:"Accepts the Minecraft EULA so your server can start.",c:"eula=true\n"},
  {n:"ops-guide.txt",d:"How to connect, op yourself and make backups.",c:"1. Connect with your server IP in Multiplayer.\n2. Run: op YourName in the console.\n3. Backup: stop the server and zip the world folder.\n"}
 ];
 $("#dlGrid").innerHTML=FILES.map((f,i)=>`<div class="card"><h3>${f.n}</h3><p style="font-size:14px;margin:6px 0 14px">${f.d}</p><button class="btn" data-dl="${i}">Download</button></div>`).join("");
 document.querySelectorAll("[data-dl]").forEach(b=>b.onclick=()=>{
  const f=FILES[b.dataset.dl],u=URL.createObjectURL(new Blob([f.c],{type:"text/plain"})),a=document.createElement("a");
  a.href=u;a.download=f.n;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(u)
 });
}
